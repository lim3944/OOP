
import java.util.*;
import java.lang.String;

public class Student implements Comparable<Student>{
	private String name;
	private String id;
	private int numLoans;
	private int numReserves;
	
	private HashSet<LibraryItem> onLoan;
	private HashSet<LibraryItem> onReserve;
	
	public Student(String name, String id){
		this.name = name;
		this.id = id;
		this.numLoans = 0;
		this.numReserves = 0;
		
		this.onLoan = new HashSet<LibraryItem>();
		this.onReserve = new HashSet<LibraryItem>();
	}
	
	public String getName(){
		return this.name;
	}
	
	public String getIdNumber(){
		return this.id;
	}
	
	public int getNumReserve(){
		return this.numReserves;
	}
	
	public int getNumLoan(){
		return this.numLoans;
	}
	
	public void setNumLoan(int num){
		this.numLoans = num;
	}
	
	public void setNumReserve(int num){
		this.numReserves = num;
	}
	
	public boolean equals(Student S){
		if(S.getIdNumber() == this.getIdNumber())
			return true;
		return false;
	}
	
	public int compareTo(Student S){
		Integer idS = Integer.parseInt(S.getIdNumber());
		Integer idThis = Integer.parseInt(this.getIdNumber());
		if(idS == idThis)
			return 0;
		else if(idS>idThis)
			return 1;
		else return -1;
	}
	
	public String toString(){
		String n1 = "============Stdent Record============\n"+"Name: "+
		this.getName()+"\n"+"id number: "+
		this.getIdNumber()+"\n"+"onLoan: "+
		this.getNumLoan()+"\n"+"onReserve: "+
		this.getNumReserve()+"\n";
		n1+="----------------onloan----------------\n";
		for(LibraryItem entry : this.onLoan)
			n1 += entry.toString();
		n1+="--------------onreserve-------------\n";
		for(LibraryItem entry : this.onReserve)
			n1 += entry.toString();
		n1+="====================================\n";
		return n1;
	}
	
	public boolean acquireItem(LibraryItem B){
		try{
			if(B instanceof GeneralWorks){
				if((!this.onLoan.contains(B)) && ((GeneralWorks) B).loanItem()){
					this.setNumLoan(this.getNumLoan()+1);
					return this.onLoan.add(B);
				}
			}
			else if(B instanceof ReservedWorks){
				if((!this.onReserve.contains(B)) && ((ReservedWorks) B).reserveItem()){
					this.setNumReserve(this.getNumReserve()+1);
					
					return this.onReserve.add(B);
				}
			}
			else{
				throw new Exception("Not Valid");
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
			return false;
	}
	
	public boolean releaseItem(LibraryItem B){
		try{
			if(B instanceof GeneralWorks){
				if((this.onLoan.contains(B)) && ((GeneralWorks) B).returnItem()){
					this.setNumLoan(this.getNumLoan()-1);
					return this.onLoan.remove(B);
				}
			}
			else if(B instanceof ReservedWorks){
				if((this.onReserve.contains(B)) && ((ReservedWorks) B).returnItem()){
					this.setNumReserve(this.getNumReserve()-1);
					return this.onReserve.remove(B);
				}
			}
			else{
				throw new Exception("Not Valid");
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
			return false;
	}
}
