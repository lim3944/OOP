
public interface Loanable {
	public boolean loanItem();
}
