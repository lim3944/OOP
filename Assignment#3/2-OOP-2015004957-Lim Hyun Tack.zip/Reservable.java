
public interface Reservable {
	public boolean reserveItem();
}
