
public abstract class LibraryItem implements Comparable<LibraryItem>{
	protected String id;
	protected String title;
	protected String author;
	int availableUnits;
	
	public LibraryItem(String id, String title, String author, int availableUnits){
		this.id = id;
		this.title = title;
		this.author = author;
		this.availableUnits = availableUnits;
	}
	
	public int getAvailableUnits(){
		return this.availableUnits;
	}
	
	public void setAvailableUnits(int availableUnits){
		this.availableUnits=availableUnits;
	}
	
	public String getTitle(){
		return this.title;
	}
	
	public String getAuthor(){
		return this.author;
	}
	
	public String getId(){
		return this.id;
	}
	
	public String toString(){
		String n1 = "Title: "+this.getTitle()+"\n";
		String n2 = "ID: "+this.getId()+"\n";
		String n3 = "Author: "+this.getAuthor()+"\n";
		String n4 = "Units Available: "+this.getAvailableUnits()+"\n";
		return n1+n2+n3+n4+"------------------------\n";
	}
	
	public boolean equals(LibraryItem L){
		if(L.getId() == this.getId())
			return true;
		return false;
	}
	
	public int compareTo(LibraryItem L){
		return this.id.compareTo(L.id);
	}
	
	public abstract boolean returnItem();
}