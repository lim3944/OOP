
import java.util.*;
import java.io.*;

public class LibraryInfoSystem {
	private static final String BOOKSINPUTFILE 
	= "C:\\Users\\samsung\\Desktop\\�Ѿ���б�\\2-1\\��ü����\\�ǽ�\\Assignment#3\\BOOKSINPUTFILE.txt";
	private static final String STUDENTSINPUTFILE 
	= "C:\\Users\\samsung\\Desktop\\�Ѿ���б�\\2-1\\��ü����\\�ǽ�\\Assignment#3\\STUDENTSINPUTFILE.txt";
	
	private static ArrayList<LibraryItem> books = new ArrayList<LibraryItem>();
	private static ArrayList<Student> students = new ArrayList<Student>();
	
	private static void init(){
		Scanner inputStream = null;
		
		
		//Book info
		try{
			inputStream = new Scanner(new FileInputStream(BOOKSINPUTFILE));
			
			while (inputStream.hasNextLine()){
					
				String id,title,author,type;
				String str = inputStream.nextLine();
				StringTokenizer values = new StringTokenizer(str,"#");
				
				id = values.nextToken();
				title = values.nextToken();
				author = values.nextToken();
				type = values.nextToken();

				if (type.equals("G")){
					GeneralWorks temp = new GeneralWorks(id,title,author);
					books.add(temp);
				}
				else {
					ReservedWorks temp = new ReservedWorks(id, title, author);
					books.add(temp);
				}
			}
			
		}
		catch(FileNotFoundException e){
			System.out.println("File BOOKSINPUTFILE was not found.");
		}
		
		//Student info
		try{
			inputStream = new Scanner(new FileInputStream(STUDENTSINPUTFILE));
			
			while (inputStream.hasNextLine()){
				String str = inputStream.nextLine();
				StringTokenizer values=new StringTokenizer(str, "#");
				
				String name,id;
				
				name = values.nextToken();
				id = values.nextToken();
				
				Student temp = new Student(name,id);
				
				students.add(temp);
			}
		}
		catch(FileNotFoundException e){
			System.out.println("File STUDENTINPUTFILE was not found.");
		}
		
	}
	
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		
		boolean chk = true;
		
		init();
		
		while(chk){
			System.out.println("*******Library Management System*******");
			System.out.println("(1) Borrow an Item:");
			System.out.println("(2) Return an Item:");
			System.out.println("(3) Search for Book");
			System.out.println("(4) Search for Studnet");
			System.out.println("(5) Exit the program");
			System.out.println("***************************************");
			
			int selec = scan.nextInt();
			
			switch(selec){
			//Borrow
			case 1:{
				Student s = null;
				LibraryItem b = null;
				
				System.out.println("Please enter Student's Id:");
				String id = scan.next();
				
				//id check
				boolean itemChek = false;
				for(Student entry : students){
					if ( entry.getIdNumber().equals(id) ) {
						s = entry;
						itemChek = true;
						break;
					}
				}
				if(itemChek == false){
					System.out.println("No such Student");
					break;
				}
				
				System.out.println("Please enter th id of the item to borrow:");
				id=scan.next();
				
				//book check
				itemChek=false;
				for(LibraryItem entry : books){
					if(entry.getId().equals(id)){
						b = entry;
						itemChek = true;
						break;
					}
				}
				if(itemChek == false){
					System.out.println("No such Book");
					break;
				}
					
				//item borrow
				if(b instanceof GeneralWorks){
					if(s.acquireItem(b))
						System.out.println("Book successfully loaned");
					else
						System.out.println("Loan failed");
				}
				else{
					if(s.acquireItem(b))
						System.out.println("Book successfully reserved");
					else
						System.out.println("Rerevation failed");
				}
				
				break;
			}
			//Return
			case 2:{				
				Student s = null;
				LibraryItem b = null;
				
				System.out.println("Please enter Student's Id:");
				String id = scan.next();
				
				//id check
				boolean itemChek = false;
				for(Student entry : students){
					if(entry.getIdNumber().equals(id)){
						s = entry;
						itemChek = true;
						break;
					}
				}
				if(itemChek == false){
					System.out.println("No such Student");
					break;
				}
				
				System.out.println("Please enter th id of the item to return:");
				id=scan.next();
				
				//book check
				itemChek = false;
				for(LibraryItem entry : books){
					if(entry.getId().equals(id)){
						b=entry;
						itemChek = true;
						break;
					}
				}
				if(itemChek == false){
					System.out.println("No such Book");
					break;
				}
				
				//item release
				if(s.releaseItem(b))
					System.out.println("Book successfully returned");
				else
					System.out.println("Unable to returned:");
				
				break;
			
			}
			
			//Search book	
			case 3:{
				System.out.println("Please enter the item's id number:");
				String id = scan.next();
				
				//book check
				boolean itemChek = false;
				for(LibraryItem entry : books){
					if(entry.getId().equals(id)){
						itemChek = true;
						System.out.println(entry.toString());
						break;
					}
				}
				
				if(itemChek == false)
					System.out.println("No such Book");
				
				break;
			}
			
			//Search student
			case 4:{
				System.out.println("Please enter Student's Id:");
				String id = scan.next();
				
				//id check
				boolean itemChek = false;
				for(Student entry : students){
					if(entry.getIdNumber().equals(id)){
						itemChek = true;
						System.out.println(entry.toString());
						break;
					}
				}
				
				if(itemChek == false)
					System.out.println("No such Student");
				
				break;
			}
			
			//exit
			case 5:{
				System.out.println("Exit the program");
				chk = false;
			}

			default:
				System.out.println("Please select right menu");
			}
		}
	}
}
