
public class GeneralWorks extends LibraryItem implements Loanable{
	
	public GeneralWorks(String id, String title, String author){
		super(id,title,author,5);
	}
	
	public boolean loanItem(){
		if(super.getAvailableUnits()>0){
			super.setAvailableUnits(super.getAvailableUnits()-1);
			return true;
		}
		return false;
	}
	
	public boolean returnItem(){
		if(super.getAvailableUnits()<5){
			super.setAvailableUnits(super.getAvailableUnits()+1);
			return true;
		}
		return false;
	}
}
