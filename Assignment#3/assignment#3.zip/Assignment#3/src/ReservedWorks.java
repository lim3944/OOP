
public class ReservedWorks extends LibraryItem implements Reservable{
	
	public ReservedWorks(String id,String title, String author){
		super(id, title, author, 1);
	}
	
	public boolean reserveItem(){
		if(super.getAvailableUnits()>0){
			super.setAvailableUnits(super.getAvailableUnits()-1);
			return true;
		}
		return false;
	}
	
	public boolean returnItem(){
		if(super.getAvailableUnits() == 0){
			super.setAvailableUnits(1);
			return true;
		}
		return false;
	}
}
